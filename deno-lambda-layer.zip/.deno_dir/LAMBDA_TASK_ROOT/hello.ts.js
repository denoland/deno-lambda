export async function handler(event, context) {
    return {
        statusCode: 200,
        body: `Welcome to deno ${Deno.version.deno} 🦕`
    };
}
//# sourceMappingURL=hello.js.map